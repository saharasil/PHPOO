</main>
    <footer class="bg-dark text-light text-center py-4">
        &copy; <?= date('y')?> Gestion des employés - Tous droits réservés
    </footer>
    
</body>
</html>