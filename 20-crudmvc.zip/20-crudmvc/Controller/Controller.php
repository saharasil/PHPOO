<?php
namespace Controller;

class Controller{
    private $db;
    public function __construct(){
        $this->db = new \Model\EntityRepository;
    }
    public function redirect($location){
        header('location:' . $location);
        exit();
    }
    // la méthode pour lancer l'application
    public function run(){
         //  la condition en  forme ternaire
        // $op = (isset($_GET['op'])) ? $_GET['op'] : 'list';

        $op = $_GET['op'] ?? 'list'; // si existe op dans $GET si non j'affiche  'list'
        switch($op){
            case 'list' : $this->listALL();
        break;
            case 'new' :
            case 'edit':
                 $this->register();
        break;
            case'delete' :$this->delete();
        break;
        }

    }

    public function listAll(){
        $donnees =$this->db->selectAll();
        $title  = '| Liste'; //pour afficher " liste " dans le title en haut du navigateur
        require('View/employes.php');
    }
    public function register(){
        //on va gérer insertion et modification d'un employé
        // $donnees =$this->db->();
        require('View/formulaire.php');
    }
    public function delete(){
        // ex : ?op=delete$id=
        // id existe et n'est pas vide, et est de nature numérique 
        if(!empty($_GET['id']) && is_numeric($_GET['id'])){
        $donnees =$this->db->delete($_GET['id']);
        }

        $this->redirect('?op=list');
        
    }
    
    
    
    


}